%This code will get data from the Arduino Due, take the FFT and then 
%plot the results

clear;
clc;
%%What COM port is the Bluetooth connected to%%
port='COM31';
%how many samples are there transmited
samples=501;
%Length of the FFT
length=1102;

%Half period of the trianble wave
Tp=25e-3;
%Bandwidth
BW=2.8e9-2.1e9;
rr=3e8/(2*BW);

%2d matrix that represents range v time
range=ones(100,length/2).*-60;

%seting up a serial objects for COM
com=serial(port,'BaudRate',4*115200);
fopen(com);
%gete the first samples
k=1;
fprintf(com,'%c','s');
for i=1:samples
    a=fgets(com);
    data(1,k)=str2double(a);
    k=k+1;
end
%extract the sampling frequincy which is the last number transmitted
samplinf=data(1,samples);
data=data(1,1:samples-1);
%take the fft
ft=fft(data,length);
ft(1:2)=0;
ft=abs(ft(1:length));
%pot the fft
%figure(1);
%stem(ft);

N=Tp*24800;
max_range=rr*N/2;
%add the data to range
range=[ft(1:length/2);range(1:99,:)];
 figure(2);
 %plot range
 imagesc(linspace(0,max_range,550),1:100,range,[-80 200]);
linkdata on;

%loop that runs until canceld constently geting data from the DUE
while 1==1 
k=1;
clear data;
%tell the DUE to transmit data
fprintf(com,'%c','s');
for i=1:samples
    %samve the transmited data in matrix
    a=fgets(com);
    data(1,k)=str2double(a);
    k=k+1;

end
%extract the sampling frequincy
samplinf=data(1,samples);
data=data(1,1:samples-1);
%take the fft
ft=fft(data,length);
ft(1:2)=0;
ft=abs(ft(1:length/2));
%max_abs=max(max(ft));

%ft=mag2db(ft);
%range=[ft-range(1,:);range(1:99,:)];
range=[ft;range(1:99,:)];

%stem the fft
figure(1);
stem(ft);
refreshdata
%plot range v time intencity
figure(2);
imagesc(linspace(0,max_range-52,200),1:100,range(:,1:200),[-80 200]);
xlabel('Range in Meters');
ylabel('Time (s)');
refreshdata
end