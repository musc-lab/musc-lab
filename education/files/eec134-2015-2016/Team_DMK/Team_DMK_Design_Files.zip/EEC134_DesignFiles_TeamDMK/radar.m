%v1, v2, v3 are the names of the test files of the competition
clear;
close all;
[Y,FS,NBITS] = wavread('v3.wav');
c = 3E8; 
Tp = 20E-3; 
N = Tp*FS; 
fstart = 2260E6; 
fstop = 2590E6; 
BW = fstop-fstart; 
f = linspace(fstart, fstop, N/2); 
rr = c/(2*BW);
max_range = rr*N/2;
trig = -1*Y(:,1);
s = -1*Y(:,2);
clear Y;
count = 0;
thresh = 0;
start = (trig > thresh);
for ii = 100:(size(start,1)-N)
if start(ii) == 1 && mean(start(ii-11:ii-1)) == 0
count = count + 1;
sif(count,:) = s(ii:ii+N-1);
time(count) = ii*1/FS;
end
end
ave = mean(sif,1);
for ii = 1:size(sif,1);
sif(ii,:) = sif(ii,:) - ave;
end
zpad = 8*N/2;
figure(10);
v = dbv(ifft(sif,zpad,2));
S = v(:,1:size(v,2)/2);
m = max(max(v));
imagesc(linspace(0,max_range,zpad),time,S-m,[-80, 0]);
colorbar;
ylabel('time (s)');
xlabel('range (m)');
title('RTI without clutter rejection');
figure(20);
sif2 = sif(2:size(sif,1),:)-sif(1:size(sif,1)-1,:);
v = ifft(sif2,zpad,2);
S=v;
R = linspace(0,max_range,zpad);
S = dbv(S(:,1:size(v,2)/2));
m = max(max(S));
imagesc(R,time,S-m,[-80, 0]);
colorbar;
ylabel('time (s)');
xlabel('range (m)');
title('RTI with 2-pulse cancelor clutter rejection');