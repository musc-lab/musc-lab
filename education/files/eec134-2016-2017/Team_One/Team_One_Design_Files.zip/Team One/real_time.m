close all;
clear all;
%setting the frequency of sample of soundcard
%using audio funtion to record the digital data
FS=44100
recObj = audiorecorder(44100, 16, 2);
disp('Start speaking.')
recordblocking(recObj, 20);
disp('End of Recording.');
q= getaudiodata(recObj);
plot(q);
data = 0;
%figure;
%plot(q);
load handel.mat
filename = 'handel.wav';
wavwrite(q,Fs,filename);
clear q Fs
[q,Fs] = wavread(filename);
sound(q,Fs);
%setting the parameter
FS=44100
c = 3E8;% speed of light
Tp = 12.8E-3; %(s) pulse time
N = Tp*FS; %# of samples per pulse
fstart = 2300E6; %(Hz) LFM start frequency
fstop = 2560E6; %(Hz) LFM stop frequency
BW = fstop-fstart; %(Hz) transmti bandwidth
f = linspace(fstart, fstop, N/2); %instantaneous transmit frequency
%range resolution
rr = c/(2*BW);
max_range = rr*N/2;
[Y,FS] = wavread('handel.wav');%the input appears to be inverted
trig = -1*Y(:,1);%SYNC signal
%[Y,FS] = audioread('HU3.wav');
s = -1*Y(:,2);%radar signal
%parse the data here by triggering off rising edge of sync pulse
count = 0;
thresh = 0;
start = (trig > thresh);%convert data into binary
d=size(start,1)-N;
for ii = 100:(d)
if start(ii) == 1 & mean(start(ii-11:ii-1)) == 0
%start2(ii) = 1;
count = count + 1;
sif(count,:) = s(ii:ii+N-1);
time(count) = ii*1/FS;
end
end
disp('end_for')
%subtract the average
ave = mean(sif,1);
for ii = 1:size(sif,1);
sif(ii,:) = sif(ii,:) - ave;
end
zpad = 8*N/2;
%RTI plot
figure(10);
dbv = fft(sif,zpad,2);
v=dbv;
S =abs(v(:,1:size(v,2)/2));
m =mean(mean(v));
Z=S-m;
Z=abs(Z);
%Z=Z/abs((max(max(Z))));
%Z=20*log10(Z);
U=linspace(0,max_range,zpad);
imagesc(U,time,Z);
colorbar;
ylabel('time (s)');
xlabel('range (m)');
title('RTI without clutter rejection');

%pulse cancelor RTI plot
figure(20);
sif2 = sif(2:size(sif,1),:)-sif(1:size(sif,1)-1,:);
v = fft(sif2,zpad,2);
p=v;
R = linspace(0,max_range,zpad);
abv=p(:,1:size(v,2)/2);
m =mean(mean(p));
J=abs(p-m);
J=J/abs((max(max(J))));
J=20*log10(J);
K=J(:,1:size(J,2)/2);
imagesc(R,time,K);
colorbar;
ylabel('time (s)');
xlabel('range (m)');
title('RTI with 2-pulse cancelor clutter rejection');

